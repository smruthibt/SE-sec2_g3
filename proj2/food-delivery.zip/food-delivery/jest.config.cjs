module.exports = {
  testEnvironment: "node",
  transform: {},
};
