import express from 'express';
import Order from '../models/Order.js';
import Driver from '../models/Driver.js';
const router = express.Router();


router.get('/orders/new', async (req, res) => {
  try {
    const orders = await Order.find({ 
    status: { $in: ["placed", "preparing"] },
    driverId: null});
    res.json(orders);
  } catch (err) {
    res.status(500).send('Error fetching new orders');
  }
});


router.post('/orders/accept/:id', async (req, res) => {
  try {
    const driverId = req.session.driverId;
    const order = await Order.findByIdAndUpdate(req.params.id, {
      driverId,
      status: 'out_for_delivery'
    });
    res.json({ message: 'Order accepted', order });
  } catch (err) {
    res.status(500).send('Error accepting order');
  }
});


router.get('/orders/pending', async (req, res) => {
  try {
    const driverId = req.session.driverId;
    const orders = await Order.find({ driverId, status: 'out_for_delivery' });
    res.json(orders);
  } catch (err) {
    res.status(500).send('Error fetching pending deliveries');
  }
});


router.post('/orders/delivered/:id', async (req, res) => {
  try {
    const order = await Order.findByIdAndUpdate(req.params.id, { status: 'delivered' });
    res.json({ message: 'Order marked as delivered', order });
  } catch (err) {
    res.status(500).send('Error marking delivered');
  }
});


router.get('/payments', async (req, res) => {
  try {
    const driverId = req.session.driverId;
    const { start, end } = req.query;
    const startDate = new Date(start);
    const endDate = new Date(end);

    const payments = await Order.find({
      driverId,
      status: 'delivered',
      updatedAt: { $gte: startDate, $lte: endDate }
    }).select('deliveryPayment updatedAt');

    const total = payments.reduce((sum, o) => sum + o.deliveryPayment, 0);
    res.json({ total, payments });
  } catch (err) {
    res.status(500).send('Error fetching payments');
  }
});

export default router;
